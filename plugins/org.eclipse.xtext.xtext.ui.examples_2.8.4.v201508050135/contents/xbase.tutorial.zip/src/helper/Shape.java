package helper;

public interface Shape {
}
