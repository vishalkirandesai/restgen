/**
 */
package org.eclipse.xtext.example.homeautomation.ruleEngine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.example.homeautomation.ruleEngine.RuleEnginePackage#getDeclaration()
 * @model
 * @generated
 */
public interface Declaration extends EObject
{
} // Declaration
